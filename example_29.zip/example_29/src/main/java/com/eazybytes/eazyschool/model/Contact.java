package com.eazybytes.eazyschool.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class Contact {

    @NotBlank(message = "Name should not be Blank")
    @Size(min = 3, message = "Size must contains min 3 char ")
    private String name;

    @NotBlank(message = "Number should not be Blank")
    @Pattern(regexp ="([0-9]{10})", message = "Enter valid number")
    private String mobileNum;

    @NotBlank(message = "Email should not be Blank")
    @Email(message = "Enter valid email")
    private String email;

    @NotBlank(message = "Subject should not be Blank")
    @Size(min = 3)
    private String subject;

    @NotBlank(message = "Subject should not be Blank")
    @Size(min = 10)
    private String message;


}
